library(shiny)
library(text2vec)
library(DT)
library(proxy)
library(tidyverse)
library(readxl)
library(dplyr)
library(stringr)
library(tidytext)

# ---- Load Data ----
data <- read_excel("ISB367-XLS-ENG.xlsx")

# Rename columns
colnames(data) <- c("RLY", "SHORTNAME", "PUR_DIV", "PUR_DIV_NAME", "PO_NO", "PO_SR", 
                    "PL_NO", "BU", "DES", "CONSIGNEE", "CONS_NAME", "PO_DATE")

# Convert date and remove missing values
data <- data %>%
  mutate(PO_DATE = as.POSIXct(PO_DATE, format = "%d-%b-%y %H:%M:%S", tz = "UTC")) %>%
  filter(!is.na(DES))

# Clean text
data <- data %>%
  mutate(DES_CLEAN = str_to_lower(DES),
         DES_CLEAN = str_replace_all(DES_CLEAN, "[^[:alnum:] ]", " "),
         DES_CLEAN = str_squish(DES_CLEAN))

tokens_grouped <- data %>%
  select(PO_NO, DES_CLEAN) %>%
  distinct()

# ---- Precompute TF-IDF ----
it <- itoken(tokens_grouped$DES_CLEAN, preprocessor = tolower, tokenizer = word_tokenizer, ids = tokens_grouped$PO_NO)
vectorizer <- vocab_vectorizer(vocabulary = create_vocabulary(it))
dtm <- create_dtm(it, vectorizer)
tfidf <- TfIdf$new()
dtm_tfidf <- tfidf$fit_transform(dtm)

# ---- UI ----
ui <- fluidPage(
  titlePanel("Indian Railways Procurement Search (TF-IDF)"),
  sidebarLayout(
    sidebarPanel(
      textInput("query", "Enter item description:", placeholder = "e.g., pen drive 16 GB"),
      actionButton("search", "Search"),
      br(),
      br(),
      helpText("Results based on TF-IDF + Cosine Similarity")
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Search Results", DTOutput("results_table")),
        tabPanel("Visualizations",
                 h4("Top 10 Words in Descriptions"),
                 plotOutput("top_words"),
                 h4("POs Over Time"),
                 plotOutput("po_trend"),
                 h4("Top Purchase Divisions"),
                 plotOutput("top_divisions")
        )
      )
    )
  )
)

# ---- SERVER ----
server <- function(input, output, session) {
  
  # ---- TF-IDF Search Logic ----
  result_data <- eventReactive(input$search, {
    req(input$query)
    # Ensure consistent lowercasing of query
    clean_query <- tolower(input$query)
    query_it <- itoken(clean_query, progressbar = FALSE, tokenizer = word_tokenizer)
    query_dtm <- create_dtm(query_it, vectorizer)
    query_tfidf <- tfidf$transform(query_dtm)
    similarities <- sim2(dtm_tfidf, query_tfidf, method = "cosine", norm = "l2")
    top_indices <- order(similarities[, 1], decreasing = TRUE)[1:5]
    tokens_grouped[top_indices, ]
  })
  
  output$results_table <- renderDT({
    datatable(result_data(), options = list(pageLength = 5), rownames = FALSE)
  })
  
  # ---- EDA Visualizations ----
  
  # Top 10 words in item descriptions
  output$top_words <- renderPlot({
    data %>%
      unnest_tokens(word, DES_CLEAN) %>%
      count(word, sort = TRUE) %>%
      filter(n > 10) %>%
      top_n(10, n) %>%
      ggplot(aes(x = reorder(word, n), y = n)) +
      geom_col(fill = "steelblue") +
      coord_flip() +
      labs(x = "Words", y = "Frequency", title = "Top 10 Words in Descriptions")
  })
  
  # POs over time
  output$po_trend <- renderPlot({
    data %>%
      mutate(YearMonth = format(PO_DATE, "%Y-%m")) %>%
      count(YearMonth) %>%
      ggplot(aes(x = YearMonth, y = n)) +
      geom_line(group = 1, color = "darkgreen") +
      theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
      labs(x = "Month", y = "Number of POs", title = "Purchase Orders Over Time")
  })
  
  # Top Purchase Divisions
  output$top_divisions <- renderPlot({
    data %>%
      count(PUR_DIV_NAME, sort = TRUE) %>%
      top_n(10, n) %>%
      ggplot(aes(x = reorder(PUR_DIV_NAME, n), y = n)) +
      geom_col(fill = "tomato") +
      coord_flip() +
      labs(x = "Division", y = "Number of POs", title = "Top Purchase Divisions")
  })
}

# ---- Run App ----
shinyApp(ui = ui, server = server)
